﻿using HospitalManagement.Controller;
using System;

namespace HospitalManagement
{
    class Program
    {
        public void Menu()
        {
            HospitalController hospitalController = new HospitalController();    

            Console.WriteLine("1.Hospital Admin\n
                               2.View Departments & Doctors\n
                               3.Handle Doctor\n
                               4.Exit \n");

            Console.Write("Enter Choice : ");
            int input = Convert.ToInt32(Console.ReadLine());

            switch (input)
            {
                case 1:
                    hospitalController.HospitalAdmin();
                    break;

                case 2:
                    hospitalController.ViewDepartment();
                    break;

                case 3:
                    hospitalController.HandleDoctor();
                    break;

                case 4:
                    System.Environment.Exit(0);
                    break;        
            }
        }
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Menu();
        }
    }
}
